create or replace trigger tr3
before insert on order_1
for each row
declare
total_bill integer;
tt integer := 0;

function total_amountko(c_id number) return number is
cursor c_c is
select * 
from basket;
dish_price integer := 0;
total integer := 0;
begin
for row in c_c loop
if row.CLIENT_ID = c_id then
    select menu_price into dish_price
    from menu
    where menu_id = row.menu_id;
    total := total + dish_price;
    dish_price := 0;
end if;
end loop;
return total;
end;

begin
if :new.order_status = 'runout' then
select count(*) into total_bill
from bill;
tt := total_amountko(:new.client_id);
insert into bill values(total_bill, tt, 200, :new.client_id, 'CARD');
delete from basket where client_id = :new.client_id;
end if;
end;
/