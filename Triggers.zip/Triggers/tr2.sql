create or replace trigger tr2
before insert on order_1
for each row
declare
idd number;
begin
if :new.order_status = 'runout' then
select order_id into idd
from order_1
where table_id = :new.table_id and :new.client_id = client_id and order_time = :new.order_time and order_status = 'reservation';
DELETE FROM order_1 WHERE order_id = idd;
DELETE FROM order_1 WHERE order_id = :new.order_id;
end if;
end;
/