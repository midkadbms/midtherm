create or replace trigger tr1
before insert on order_1
for each row
declare
order_statusk order_1.ORDER_STATUS%type := :new.order_status;
order_idk order_1.ORDER_ID%type := :new.order_id;
order_timek order_1.ORDER_TIME%type := :new.order_time;
hour_str varchar2(255);
minus_str varchar2(255);
hour_int integer;
minus_int integer;
total_order integer;
h_int integer;
m_int integer;

cursor c is
select *
from order_1
where order_status = 'reservation' and table_id = :new.table_id;
begin

DBMS_OUTPUT.PUT_LINE(order_idk || ' ' || order_statusk || ' ' || order_timek);
hour_str := SUBSTR(order_timek, 1, INSTR(order_timek, ':' ) - 1);
minus_str := SUBSTR(order_timek, INSTR(order_timek, ':' ) + 1);
DBMS_OUTPUT.PUT_LINE(hour_str || ' ' || minus_str);
hour_int := TO_NUMBER(hour_str);
minus_int := TO_NUMBER(minus_str);

select count(*) into total_order
from order_1
where order_status = 'reservation' and client_id = :new.client_id;

DBMS_OUTPUT.PUT_LINE(total_order);

if :new.order_status != 'runout' then
if total_order = 1 then
RAISE_APPLICATION_ERROR (-20001, 'Ol clientte uje reservnii stol bar');
else
for row in c loop
h_int := TO_NUMBER(SUBSTR(row.order_time, 1, INSTR(row.order_time, ':' ) - 1));
m_int := TO_NUMBER(SUBSTR(row.order_time, INSTR(row.order_time, ':' ) + 1));
if (h_int + 1) = hour_int or (h_int = hour_int) or (hour_int + 1) = h_int then
RAISE_APPLICATION_ERROR (-20001, 'Uje reservnii uakit bar ol stolikta');
elsif (((h_int + 2) = hour_int) and (m_int >= minus_int)) or (hour_int + 2 = h_int and minus_int >= m_int)then
RAISE_APPLICATION_ERROR (-20001, 'Uje reservnii uakit bar ol stolikta');
end if;
end loop;
end if;
end if;
end;
/