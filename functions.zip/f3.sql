create or replace function f3 return VARCHAR2 is
TOTAL integer := 0;
t varchar(32767);
tt integer := 0;
total_clients integer;
i integer := 1;
b boolean := FALSE;

cursor c is
select CLIENT_ID, MENU_ID
from basket;

begin 
    select count(*) into total_clients
    from clients;

    while i <= total_clients loop
        b := FALSE;
        for row in c loop
            if row.CLIENT_ID = i then 
                b := TRUE;
            end if;
        end loop;
        if b = TRUE then

            for row in c loop
                if row.CLIENT_ID = i then
                    select MENU_PRICE into tt from menu where menu_id = row.MENU_ID;
                    TOTAL := TOTAL + tt;
                end if;
            end loop;

            t := t || CHR(10) || ' Client ID is ' || i ||  ' and his total is ' || TOTAL;
            TOTAL := 0;
            tt := 0;
        end if;

        i := i + 1;
    end loop;

    return t;
end;
/