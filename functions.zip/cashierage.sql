create or replace FUNCTION cashierAge
RETURN NUMBER IS
 counts number(20):=0;

begin
  SELECT count(*) into counts FROM CASHIER WHERE CASHIER_AGE<18 ;
  RETURN counts;

 EXCEPTION
  WHEN NO_DATA_FOUND
  THEN
   RETURN 0; 
  WHEN OTHERS
  THEN
   RETURN -1; 
 END;
/